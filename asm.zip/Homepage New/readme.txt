   =-=-=-=-=-=-=-=-=-=                                     Version 1.01  
         INFO!
   =-=-=-=-=-=-=-=-=-=

-Die Aktuellste Version dieser Assembler-Homepage finden Sie unter:
 http://assembler.my100megs.com/index.html
 oder: http://www.assembler.my100megs.com/index.html
-Den Autor erreichen Sie unter: Marcus.Roming@gmx.net 
-Die Startdatei ist index.html !

16.06.01          
------------------------------------------------------------------------------   
